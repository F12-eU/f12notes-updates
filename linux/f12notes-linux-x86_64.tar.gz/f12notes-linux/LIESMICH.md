# F12 Notes

Minimalistischer Texteditor für Logbuch, Tagebuch und Notizen – fortlaufend in **einer einzigen Textdatei**.
Ein leeres Fenster, ein Cursor, sonst nichts. Alles Weitere liegt hinter einer einzigen Taste: **F12**.

Pures Rust (egui/eframe). Läuft unter Windows, Linux und macOS; ausgeliefert und getestet wird vorerst Windows/Linux.

## Starten

- **Windows:** `F12Notes.exe` starten – keine Installation nötig.
- **Linux (Mint, Ubuntu, Debian …, 64 Bit):** `dist/f12notes-linux-x86_64.tar.gz` entpacken und entweder
  `./f12notes` direkt starten oder mit `./install.sh` nach `~/F12Notes/` installieren und ins Startmenü eintragen
  (ohne sudo; zum Aktualisieren einfach erneut ausführen, `./install.sh --entfernen` macht es rückgängig).
  Läuft ab glibc 2.31, also ab Linux Mint 20.
- Beim ersten Start wird `F12Notes.txt` **im Ordner der exe** angelegt und künftig automatisch geladen
  (ist der Ordner nicht beschreibbar, z.B. unter „Programme“, stattdessen in `Dokumente`).
  Auch „Neue Notizdatei …“ schlägt den Ordner der exe vor.
- Andere Datei: F12 → „Andere Notizdatei öffnen“ oder `F12Notes.exe pfad\zur\datei.txt`.
- Portabel (USB-Stick): Liegt eine `F12Notes.txt` neben der exe, wird diese verwendet. Dateien im Ordner der exe
  (oder in Unterordnern) werden relativ zur exe gemerkt – auch zusätzliche Speicherziele (`target = sicherung/kopie.txt`).
  Der ganze Ordner kann daher verschoben oder kopiert werden.
- Autostart: F12 → „Autostart“.

## Updates

F12 Notes sucht einmal täglich still nach einer neuen Version (abschaltbar: F12 → „Täglich nach Updates suchen“).
Gibt es eine, steht „⬆ Update“ in der Titelleiste; F12 → „Update installieren“ lädt sie, prüft die Prüfsumme,
tauscht die Programmdatei aus und öffnet alle Fenster wieder. Manuell: F12 → „Nach Updates suchen“.
Die Versionen liegen öffentlich unter <https://github.com/F12-eU/f12notes-updates> (Quellcode bleibt privat).

## Mehrere Fenster

Es können mehrere Fenster mit unterschiedlichen Textdateien gleichzeitig offen sein
(jedes Fenster ist ein eigener Programmprozess mit den Einstellungen seiner Datei):

- F12 → „Notizdatei in neuem Fenster öffnen“ bzw. „Neue Notizdatei in neuem Fenster anlegen“.
- Zuletzt geöffnete Dateien erscheinen in der F12-Suche als „Öffnen: name.txt“.
- Jede Datei ist nur einmal offen: Ein zweiter Versuch holt das vorhandene Fenster nach vorn.
- Beim Start werden alle Fenster wiederhergestellt, die zuletzt offen waren
  (abschaltbar: F12 → „Fenster wiederherstellen“). Ein einzeln geschlossenes Fenster kommt nicht wieder;
  „Alle Fenster schließen“ merkt sich alle.

## Notiz auf einem anderen PC öffnen (Cloud / WebDAV)

1. Auf dem ersten PC ein WebDAV-Ziel eintragen (F12 → „Speicherziele anzeigen“ → „+ WebDAV-Ziel hinzufügen“).
   Die Notiz wird ab dann bei jedem Speichern dorthin hochgeladen.
2. Auf dem anderen PC: F12 → „Notiz aus der Cloud (WebDAV) öffnen“, die vollständige Adresse der Datei
   (z.B. `https://cloud.example.de/remote.php/dav/files/NAME/Tagebuch.txt`), Benutzer und Passwort eingeben.
   Die Notiz wird im Ordner der exe angelegt, mit allen Einstellungen, und ab dann ebenfalls in die Cloud gespeichert.
   Ist das Fenster noch leer, wird es weiterverwendet, sonst öffnet sich ein neues.

Liegt beim Eintragen eines WebDAV-Ziels unter der Adresse schon eine Notiz, fragt F12 Notes nach:
Stand aus der Cloud laden (empfohlen), lokalen Stand hochladen oder abbrechen. So wird nichts versehentlich überschrieben.

### Mehrere PCs gleichzeitig (z.B. zuhause und im Büro)

Das **erste** WebDAV-Ziel wird laufend abgeglichen (Einstellung „Cloud-Abgleich“; wird beim Hinzufügen des ersten
Cloud-Ziels automatisch eingeschaltet):

- beim Start (zuerst – erst danach werden Tagesdatum und Cursor gesetzt, so fügt nur der erste PC des Tages
  das Datum ein), nach jedem Speichern, alle 30 Sekunden (einstellbar), beim Zurückkehren ins Fenster und beim Beenden;
- Änderungen des anderen PCs werden zeilenweise mit den eigenen zusammengeführt und erscheinen von selbst;
- wurde auf beiden PCs gleichzeitig dieselbe Zeile geändert, wird **wortweise** zusammengeführt
  (z.B. „[x] Milch“ + „[ ] Milch und Brot“ → „[x] Milch und Brot“). Nur wenn dieselben Wörter unterschiedlich
  geändert wurden, steht die Fassung des anderen PCs **farbig hinterlegt** direkt dahinter (`{konflikt|…}`).
  F12 → „Nächste Konflikt-Markierung“ springt hin; behalten: „Textfarbe entfernen“, verwerfen: löschen;
- im Leerlauf wird nur gefragt, ob sich etwas geändert hat (ETag); übertragen wird nur bei Änderungen;
  Server, die ETags nicht sauber behandeln, werden erkannt – dann wird nur der Inhalt verglichen;
- der Abgleich läuft still im Hintergrund; einziger Hinweis: wenn auf zwei PCs gleichzeitig dieselbe Zeile geändert wurde;
- ohne Verbindung wird lokal weitergeschrieben und beim nächsten Kontakt zusammengeführt.
- die Titelleiste zeigt den Stand: `☁ aktuell`, `☁ wird abgeglichen …`, `☁ Cloud wird geladen …`,
  `☁ offline – Änderungen noch nicht in der Cloud`, `☁ nicht erreichbar`.

Weitere WebDAV-Ziele sind reine Kopien (werden überschrieben, nicht abgeglichen).

## Bedienung

Einfach schreiben. Gespeichert wird automatisch (Autosave, ca. 1 s nach der letzten Eingabe).

**F12** öffnet das globale Suchfeld. Es findet:

| Was | Beispiel-Eingabe |
|---|---|
| Text im Logbuch (Enter springt hin, F3 weiter) | `müller`, Regex: `/\d+ km` |
| Befehle | `ersetzen`, `gehe zu datum`, `export` |
| Einstellungen | `dunkel`, `schrift`, `markdown`, `autosave` |
| Textbausteine | `baustein` |
| Tastenkürzel (auch die Magic-Taste selbst) | `tastenkürzel`, `magic` |

Standard-Tasten (alle änderbar): `Strg+F` Suchfeld · `F3`/`Shift+F3` weitersuchen · `Strg+S` speichern ·
`Strg+Z`/`Strg+Y` · `Strg+D` Datum · `Strg+T` Uhrzeit · `F5` Datum+Uhrzeit · `Strg+B`/`Strg+I` fett/kursiv ·
`F11` Vollbild · `Strg +/-/0` Schriftgröße · `Alt+↑/↓` Zeile verschieben · `Enter` Wortvorschlag übernehmen (mit Leerzeichen), `Tab` ohne Leerzeichen, `Esc` verwerfen ·
`Strg+Klick` Link öffnen.

## Funktionen

- **Zeitstempel je Zeile:** Jede Zeile führt ihr Änderungsdatum mit. In der Datei steht es als
  `[2026-11-12 08:46:33]` vor der Zeile, im Editor ist es ausgeblendet (einblendbar).
  Beim Ziehen der Scrollleiste wird das Änderungsdatum der angezeigten Stelle eingeblendet.
- **Erscheinungsbild:** Dunkelmodus, Schriftart (Standard: Systemschrift, unter Windows Segoe UI; alle Systemschriften wählbar), Schriftgröße, Zeilenabstand, Rand,
  maximale Textbreite, eigene Farben – alles dauerhaft gespeichert.
- **Markdown-Formatierung** – eine Einstellung mit drei Werten: **ein** (Zeichen wie `#`, `**`, `{rot|…}` sind
  ausgeblendet; Pfeiltasten und Löschen überspringen sie), **aus** (Zeichen sichtbar, keine Formatierung) und
  **in aktueller Zeile** (formatiert, die Zeichen erscheinen nur in der Zeile mit dem Cursor): `# Überschrift`, `**fett**`, `*kursiv*`, `` `Code` ``, `~~durchgestrichen~~`,
  Listen, `> Zitat`, Codeblöcke, Links.
  `[]` oder `[ ]` wird zur Checkbox – am Zeilenanfang, nach `- ` oder mitten im Text
  (`Test [ ] Aufgabe`); ein Klick hakt sie ab (`[x]`),
  Enter setzt die Aufgabenliste fort.
  `- ` am Zeilenanfang wird als Aufzählungspunkt gezeichnet, `->`, `<-` und `<->` als Pfeile.
  In der Datei bleibt jeweils der getippte Text stehen.
- **Textfarben** (abschaltbar): `{rot|Text}` oder `{#1a73e8|Text}` – per F12 → „Textfarbe“ auf die Auswahl anwendbar.
- **Automatisches Färben:** Regeln aus Regex + Farbe. Voreingestellt: Datum, Uhrzeit, TODO/WICHTIG, #Tags.
- **Textbausteine mit Variablen:** `{date} {time} {datetime} {date_long} {date_iso} {time_s} {weekday}
  {weekday_short} {month_name} {year} {month} {day} {hour} {minute} {second} {week} {date+1} {date-1}
  {date:%d.%m.%y} {selection} {clipboard} {cursor} {filename} {user} {computer}`.
- **Frei belegbare Tastenkürzel** für Befehle, Bausteine, Formatierungen (`wrap:**|**`, `prefix:# `),
  Ersetzen in der Cursorzeile (`replace_line:[ ]|[x]` – erstes Vorkommen),
  Farben (`color:rot`) und Schalter (`toggle:markdown`).
- **Automatisches Einfügen** per Auslöser: `täglich`, `start`, `uhrzeit 12:00`, `datum 24.12.`, `wochentag Mo`;
  Position `oben`, `unten` oder `cursor`. Voreinstellung: einmal täglich das Datum ganz oben.
- **Autosave** in die Notizdatei und gleichzeitig in beliebig viele weitere Dateien und **WebDAV**-Ziele (Cloud).
  Zusätzlich täglich eine Sicherungskopie `<datei>.bak`.
  F12 → „Speicherziele anzeigen“ listet Notizdatei, Datei-Kopien und WebDAV-Ziele; dort lassen sie sich
  bearbeiten, entfernen, im Dateimanager zeigen, testen (WebDAV) oder neu anlegen.
- **Weitermachen:** Beim Start steht der Cursor am Ende der zuletzt geänderten Zeile (abschaltbar).
- **Drucken** (Strg+P bzw. F12 → „Drucken“): öffnet eine formatierte Druckansicht im Standardbrowser, der
  sofort den Druckdialog zeigt (dort auch „Als PDF speichern“). Bei Markierung nur die Auswahl;
  „Drucken mit Zeitstempeln“ setzt das Änderungsdatum jeder Zeile an den Rand.
- **Infobereich** (Windows, optional): F12 → „Schließen (X) blendet ins Symbol im Infobereich aus“ – das Fenster
  verschwindet beim Schließen neben die Uhr und läuft weiter; ein Klick auf das Symbol holt es zurück,
  „Beenden“ im Menü des Symbols (oder F12 → „Dieses Fenster schließen“) beendet wirklich. Minimieren funktioniert normal.
- **Einklappen:** Überschriften (`# …`) und Zeilen mit eingerückten Unterpunkten – Dreieck links anklicken oder `Strg+.`;
  F12 → „Alle Blöcke einklappen/ausklappen“. Der Zustand wird pro Datei auf dem jeweiligen PC gemerkt.
- **Listen einrücken:** `Tab` / `Shift+Tab` rückt in Listen und Aufgaben die ganze Zeile ein bzw. aus.
- **Links:** `Strg+K` macht aus dem markierten Text einen Link `[Text](https://…)`.
- **Erledigte Aufgaben:** Farbe (`color_done`) und Durchstreichen (`strike_done`) über F12 → „erledigt“.
- **Autovervollständigung** (Standard: ein): Wortvorschläge aus dem eigenen Text; `Enter` übernimmt
  und setzt ein Leerzeichen, `Tab` übernimmt ohne Leerzeichen, `Esc` verwirft (dann macht `Enter` wieder eine neue Zeile).
- **Alle Einstellungen stehen in derselben Textdatei** (unten angehängt, im Editor ausgeblendet).
  F12 → „Alle Einstellungen als Text bearbeiten“ zeigt sie.

## Dateiformat

```text
[2026-11-12 08:46:33] Donnerstag, 12.11.2026
[2026-11-12 08:47:10] Erste Notiz
[===== F12 Notes Einstellungen - im Programm mit F12 aendern =====]
dark = aus
font_size = 16
...
```

Reines UTF-8. Zeilen ohne Zeitstempel (z.B. mit einem anderen Editor ergänzt) werden problemlos gelesen.
Wird die Datei extern geändert (z.B. durch Cloud-Sync), lädt F12 Notes sie neu, sofern keine ungespeicherten
Änderungen vorliegen.

## Hinweise

- WebDAV-Passwörter stehen verschleiert (`enc:…`) in der Notizdatei. Das schützt nur vor zufälligem Mitlesen,
  es ist keine Verschlüsselung – am besten ein App-Passwort verwenden.
- WebDAV wird bei jedem Speichern hochgeladen; heruntergeladen wird nur auf Wunsch
  (F12 → „Notizen aus WebDAV laden“). Ein automatischer Abgleich zwischen mehreren Geräten findet nicht statt.
- Es läuft immer nur eine Instanz; ein zweiter Start holt das vorhandene Fenster nach vorn.
- Steht kein OpenGL zur Verfügung (z.B. Remote-Desktop), startet das Programm automatisch mit DirectX/Vulkan neu.

## Bauen

```bash
cargo build --release                                    # aktuelle Plattform
cargo build --release --target x86_64-pc-windows-gnu     # Windows-exe unter Linux (benötigt mingw-w64)
cargo test

# Linux-Paket, das auch auf älteren Distributionen läuft (glibc 2.31):
pip install ziglang cargo-zigbuild
cargo zigbuild --release --target x86_64-unknown-linux-gnu.2.31
```
